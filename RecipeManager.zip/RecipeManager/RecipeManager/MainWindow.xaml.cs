﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace RecipeManagerApp
{
    public partial class MainWindow : Window
    {
        private RecipeManager recipeManager;
        private List<Recipe> filteredRecipes;

        public MainWindow()
        {
            InitializeComponent();
            recipeManager = new RecipeManager();
            recipeManager.OnRecipeExceedsCalories += RecipeExceedsCaloriesHandler;
            filteredRecipes = new List<Recipe>();

            // Initialize placeholders
            AddPlaceholderText(FilterIngredientTextBox, null);
            AddPlaceholderText(FilterCaloriesTextBox, null);
        }

        // Add input fields for a new ingredient
        private void AddIngredientButton_Click(object sender, RoutedEventArgs e)
        {
            var ingredientStack = new StackPanel { Orientation = Orientation.Horizontal };

            var ingredientNameLabel = new Label { Content = "Name:", Width = 60, VerticalContentAlignment = VerticalAlignment.Center };
            var ingredientName = new TextBox { Width = 100, Margin = new Thickness(5) };

            var ingredientQuantityLabel = new Label { Content = "Quantity:", Width = 60, VerticalContentAlignment = VerticalAlignment.Center };
            var ingredientQuantity = new TextBox { Width = 50, Margin = new Thickness(5) };

            var ingredientUnitLabel = new Label { Content = "Unit:", Width = 40, VerticalContentAlignment = VerticalAlignment.Center };
            var ingredientUnit = new TextBox { Width = 50, Margin = new Thickness(5) };

            var ingredientCaloriesLabel = new Label { Content = "Calories:", Width = 60, VerticalContentAlignment = VerticalAlignment.Center };
            var ingredientCalories = new TextBox { Width = 50, Margin = new Thickness(5) };

            var ingredientFoodGroupLabel = new Label { Content = "Food Group:", Width = 80, VerticalContentAlignment = VerticalAlignment.Center };
            var ingredientFoodGroup = new TextBox { Width = 100, Margin = new Thickness(5) };

            ingredientStack.Children.Add(ingredientNameLabel);
            ingredientStack.Children.Add(ingredientName);
            ingredientStack.Children.Add(ingredientQuantityLabel);
            ingredientStack.Children.Add(ingredientQuantity);
            ingredientStack.Children.Add(ingredientUnitLabel);
            ingredientStack.Children.Add(ingredientUnit);
            ingredientStack.Children.Add(ingredientCaloriesLabel);
            ingredientStack.Children.Add(ingredientCalories);
            ingredientStack.Children.Add(ingredientFoodGroupLabel);
            ingredientStack.Children.Add(ingredientFoodGroup);

            IngredientsPanel.Children.Add(ingredientStack);
        }

        // Add input fields for a new step
        private void AddStepButton_Click(object sender, RoutedEventArgs e)
        {
            var stepTextBox = new TextBox { Margin = new Thickness(5) };
            StepsPanel.Children.Add(stepTextBox);
        }

        // Add a new recipe
        private void AddRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            string name = RecipeNameTextBox.Text;

            // Validate recipe name
            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("Recipe name cannot be empty.");
                return;
            }

            Recipe recipe = new Recipe { Name = name };

            // Validate and add ingredients
            foreach (var child in IngredientsPanel.Children)
            {
                if (child is StackPanel ingredientStack)
                {
                    string ingredientName = (ingredientStack.Children[1] as TextBox)?.Text;
                    if (string.IsNullOrEmpty(ingredientName))
                    {
                        MessageBox.Show("Ingredient name cannot be empty.");
                        return;
                    }

                    if (!double.TryParse((ingredientStack.Children[3] as TextBox)?.Text, out double quantity) || quantity <= 0)
                    {
                        MessageBox.Show("Invalid quantity for ingredient.");
                        return;
                    }

                    string unit = (ingredientStack.Children[5] as TextBox)?.Text;
                    if (string.IsNullOrEmpty(unit))
                    {
                        MessageBox.Show("Unit cannot be empty.");
                        return;
                    }

                    if (!double.TryParse((ingredientStack.Children[7] as TextBox)?.Text, out double calories) || calories <= 0)
                    {
                        MessageBox.Show("Invalid calories for ingredient.");
                        return;
                    }

                    string foodGroup = (ingredientStack.Children[9] as TextBox)?.Text;
                    if (string.IsNullOrEmpty(foodGroup))
                    {
                        MessageBox.Show("Food group cannot be empty.");
                        return;
                    }

                    recipe.AddIngredient(ingredientName, quantity, unit, calories, foodGroup);
                }
            }

            // Validate and add steps
            foreach (var child in StepsPanel.Children)
            {
                string step = (child as TextBox)?.Text;
                if (string.IsNullOrEmpty(step))
                {
                    MessageBox.Show("Step cannot be empty.");
                    return;
                }

                recipe.AddStep(step);
            }

            // Add the recipe to the manager and refresh the list
            recipeManager.AddRecipe(name, recipe);
            RefreshRecipeList();
            ClearFields(); // Clear input fields after adding the recipe
        }

        // Remove a selected recipe
        private void RemoveRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            if (RecipeListView.SelectedItem != null)
            {
                string recipeName = RecipeListView.SelectedItem.ToString();
                recipeManager.RemoveRecipe(recipeName);
                RefreshRecipeList();
            }
        }

        // Display details of a selected recipe
        private void DisplayRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            if (RecipeListView.SelectedItem != null)
            {
                string recipeName = RecipeListView.SelectedItem.ToString();
                Recipe recipe = recipeManager.GetRecipe(recipeName);
                if (recipe != null)
                {
                    MessageBox.Show($"Recipe: {recipe.Name}\n" +
                                    $"Ingredients:\n{string.Join("\n", recipe.Ingredients.Select(i => $"- {i.Key}: {i.Value.quantity} {i.Value.unit}, {i.Value.calories} calories, {i.Value.foodGroup}"))}\n" +
                                    $"Steps:\n{string.Join("\n", recipe.Steps.Select((step, index) => $"{index + 1}. {step}"))}");
                }
            }
        }

        // Scale a selected recipe by a factor
        private void ScaleRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            if (RecipeListView.SelectedItem != null)
            {
                string recipeName = RecipeListView.SelectedItem.ToString();
                if (double.TryParse(ScaleFactorTextBox.Text, out double factor) && factor > 0)
                {
                    recipeManager.ScaleRecipe(recipeName, factor);
                    RefreshRecipeList();
                }
                else
                {
                    MessageBox.Show("Invalid scale factor.");
                }
            }
            else
            {
                MessageBox.Show("Select a recipe to scale.");
            }
        }

        // Apply filters to the list of recipes
        private void FilterRecipesButton_Click(object sender, RoutedEventArgs e)
        {
            string ingredient = FilterIngredientTextBox.Text;
            string foodGroup = (FilterFoodGroupComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();
            if (double.TryParse(FilterCaloriesTextBox.Text, out double maxCalories))
            {
                filteredRecipes = recipeManager.GetRecipes().Where(r =>
                    (string.IsNullOrEmpty(ingredient) || r.Ingredients.ContainsKey(ingredient)) &&
                    (foodGroup == "All" || r.Ingredients.Values.Any(i => i.foodGroup == foodGroup)) &&
                    r.CalculateTotalCalories() <= maxCalories
                ).ToList();
                RefreshRecipeList(filteredRecipes);
            }
            else
            {
                MessageBox.Show("Invalid input for maximum calories.");
            }
        }

        // Refresh the list of recipes displayed in the ListView
        private void RefreshRecipeList(IEnumerable<Recipe> recipes = null)
        {
            var recipeList = (recipes ?? recipeManager.GetRecipes()).OrderBy(r => r.Name).Select(r => r.Name).ToList();
            RecipeListView.ItemsSource = recipeList;
        }

        // Handle notification when a recipe exceeds 300 calories
        private void RecipeExceedsCaloriesHandler(string recipeName)
        {
            NotificationTextBlock.Text = $"Warning: Recipe '{recipeName}' exceeds 300 calories!";
        }

        // Event handler to clear input fields
        private void ClearFieldsButton_Click(object sender, RoutedEventArgs e)
        {
            ClearFields();
        }

        // Clear all input fields
        private void ClearFields()
        {
            RecipeNameTextBox.Text = "";

            // Clear ingredients panel
            IngredientsPanel.Children.Clear();

            // Clear steps panel
            StepsPanel.Children.Clear();
        }

        // Event handler to remove placeholder text
        private void RemovePlaceholderText(object sender, RoutedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            if (textBox.Text == textBox.Tag.ToString())
            {
                textBox.Text = "";
                textBox.Foreground = SystemColors.ControlTextBrush;
            }
        }

        // Event handler to add placeholder text
        private void AddPlaceholderText(object sender, RoutedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                textBox.Text = textBox.Tag.ToString();
                textBox.Foreground = SystemColors.GrayTextBrush;
            }
        }
    }
}
