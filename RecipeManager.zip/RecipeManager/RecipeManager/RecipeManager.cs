﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace RecipeManagerApp
{
    // Delegate for notification when a recipe exceeds 300 calories
    public delegate void RecipeNotification(string recipeName);

    // Class representing a recipe
    public class Recipe
    {
        // Properties
        public string Name { get; set; }
        public Dictionary<string, (double quantity, string unit, double calories, string foodGroup)> Ingredients { get; set; }
        public List<string> Steps { get; set; }

        // Constructor
        public Recipe()
        {
            Ingredients = new Dictionary<string, (double, string, double, string)>();
            Steps = new List<string>();
        }

        // Method to add an ingredient to the recipe
        public void AddIngredient(string name, double quantity, string unit, double calories, string foodGroup)
        {
            Ingredients.Add(name, (quantity, unit, calories, foodGroup));
        }

        // Method to add a step to the recipe
        public void AddStep(string step)
        {
            Steps.Add(step);
        }

        // Method to calculate total calories of the recipe
        public double CalculateTotalCalories()
        {
            return Ingredients.Values.Sum(ingredient => ingredient.calories * ingredient.quantity);
        }
    }

    // Class for managing recipes
    public class RecipeManager
    {
        private Dictionary<string, Recipe> recipes;
        public event RecipeNotification OnRecipeExceedsCalories;

        // Constructor
        public RecipeManager()
        {
            recipes = new Dictionary<string, Recipe>();
        }

        // Method to add a recipe to the manager
        public void AddRecipe(string name, Recipe recipe)
        {
            recipes.Add(name, recipe);

            double totalCalories = recipe.CalculateTotalCalories();
            Console.WriteLine($"Total Calories for {name}: {totalCalories}");

            if (totalCalories > 300)
            {
                OnRecipeExceedsCalories?.Invoke(name);
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Warning: Total calories exceed 300!");
                Console.ResetColor();
            }
        }

        // Method to remove a recipe from the manager
        public void RemoveRecipe(string name)
        {
            recipes.Remove(name);
        }

        // Method to display all recipes in alphabetical order
        public List<string> DisplayRecipesAlphabetically()
        {
            Console.WriteLine("Recipes (Alphabetical Order):");
            List<string> recipeNames = new List<string>();
            foreach (var recipe in recipes.OrderBy(x => x.Key))
            {
                Console.WriteLine($"- {recipe.Key}");
                recipeNames.Add(recipe.Key);
            }
            return recipeNames;
        }

        // Method to get a recipe by name
        public Recipe GetRecipe(string name)
        {
            return recipes.ContainsKey(name) ? recipes[name] : null;
        }

        // Method to scale the quantities of ingredients in a recipe
        public void ScaleRecipe(string name, double factor)
        {
            if (recipes.ContainsKey(name))
            {
                Recipe recipe = recipes[name];
                foreach (var ingredient in recipe.Ingredients)
                {
                    var updatedIngredient = (quantity: ingredient.Value.quantity * factor, unit: ingredient.Value.unit, calories: ingredient.Value.calories, foodGroup: ingredient.Value.foodGroup);
                    recipe.Ingredients[ingredient.Key] = updatedIngredient;
                }
            }
        }

        // Method to get all recipes
        public List<Recipe> GetRecipes()
        {
            return recipes.Values.ToList();
        }
    }
}
